This is "foobar":

Just run as follows to distinguish between the threads "foo" and "bar":
$./foo 5
