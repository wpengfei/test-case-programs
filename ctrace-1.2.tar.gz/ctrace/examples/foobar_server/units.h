#ifndef _UNITS__H
#define _UNITS__H

#define UNIT_MAX   100

#define UNIT_FOO   1 
#define UNIT_BAR   2 

#endif
