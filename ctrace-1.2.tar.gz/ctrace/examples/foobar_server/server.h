#ifndef _SERVER__H
#define _SERVER__H

int server_start();
void server_stop();

#endif		/* _SERVER__H */
