This is the "foobar" server:

Run this with a suitably large enough value for you to experiment with the
client:

$./foo 1000 	// run for 1000 seconds

The server will wait for requests from a client to call the various CTrace
macros.

Run the client from the directory ../foobar_client.
