/******************************************************
The transaction lock system global types

(c) 1996 Innobase Oy

Created 5/7/1996 Heikki Tuuri
*******************************************************/

#ifndef lock0types_h
#define lock0types_h

#define lock_t ib_lock_t
typedef struct lock_struct	lock_t;
typedef struct lock_sys_struct	lock_sys_t;

#endif 
