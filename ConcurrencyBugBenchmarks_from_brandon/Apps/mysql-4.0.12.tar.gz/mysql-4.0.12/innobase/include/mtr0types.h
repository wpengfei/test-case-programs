/******************************************************
Mini-transaction buffer global types

(c) 1995 Innobase Oy

Created 11/26/1995 Heikki Tuuri
*******************************************************/

#ifndef mtr0types_h
#define mtr0types_h

typedef struct mtr_struct	mtr_t;

#endif
