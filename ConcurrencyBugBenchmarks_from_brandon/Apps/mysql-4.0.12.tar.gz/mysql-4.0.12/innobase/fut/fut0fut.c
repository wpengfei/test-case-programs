/**********************************************************************
File-based utilities

(c) 1995 Innobase Oy

Created 12/13/1995 Heikki Tuuri
***********************************************************************/

#include "fut0fut.h"

#ifdef UNIV_NONINL
#include "fut0fut.ic"
#endif

