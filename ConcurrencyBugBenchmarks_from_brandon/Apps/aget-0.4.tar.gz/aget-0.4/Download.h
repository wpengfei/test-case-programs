#ifndef DOWNLOAD_H
#define DOWNLOAD_H

#include <pthread.h>

void * http_get(void *);

#endif
